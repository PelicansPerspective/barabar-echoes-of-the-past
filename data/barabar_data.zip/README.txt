Barabar Dataset
This dataset contains synthetic impulse response audio files, roughness traces, and spectrogram images for demonstration purposes.

Contents:
- barabar_impulse_responses_metadata.csv
- sudama_ir.wav
- lomas_rishi_ir.wav
- sudama_waterfall.png
- karna_chaupar_waterfall.png
- lomas_rishi_waterfall.png
- karna_chaupar_ir.wav
- barabar_roughness_traces.csv
- README.txt
